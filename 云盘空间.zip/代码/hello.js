// 示例脚本
function greet(name) {
  console.log('你好, ' + name);
}

greet('GitHub 云盘');
